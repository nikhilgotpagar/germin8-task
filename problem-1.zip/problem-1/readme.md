1. install JDK & set path
2. To compile Javac Matrix.java
3. To run JAva Matrix.
4. You cna change the given matrix and run the program with your own matrix as well.