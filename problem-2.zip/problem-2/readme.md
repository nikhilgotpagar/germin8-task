1. Isntall JDK & set path.
2. Open the cmd in given location or you can run it in IDE also.
3. To compile Javac Main.java
4. To run Java Main
5. You can change the arrays and sum to check the program with your own input.