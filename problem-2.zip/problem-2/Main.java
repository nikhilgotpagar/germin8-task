import java.util.stream.Collectors;
import java.util.stream.IntStream;

class Main
{
	
	public static void print(int[] arr, int i, int j)
	{
		System.out.println(IntStream.range(i, j + 1)
		.mapToObj(k -> arr[k])
		.collect(Collectors.toList()));
	}

	
	public static void findSubarrays(int[] arr, int sum)
	{
		for (int i = 0; i < arr.length; i++)
		{
			int current_sum = 0;

			
			for (int j = i; j < arr.length; j++)
			{  
				
				current_sum += arr[j];

				
				if (current_sum == sum) {
					print(arr, i, j);
				}
			}
		}
	}

	public static void main(String[] args)
	{
		int[] arr = { 8, 3, 5, 2, 3, 7, 1,-1, -4 };
		int sum = 7;

		findSubarrays(arr, sum);
	}
}