1. Install JDK & Set path
2. Open the cmd in given location or you can run it in IDE also.
3. To compile Javac palicheck.java
4. To run the program java Palicheck
5. You can change the input string and try with your own input as well.