1. Extract the folder.
2. Open the index.html file with chrome browser.
3. Start doing operations.